from django.urls import path
from . import views
from .views import *

urlpatterns = [
    
    path("sign_in", views.sign_in, name="sign_in"),
    path("signup/", views.sign_up, name="sign_up"),
    path("account_details/", views.account_details, name='account_details'),
    path('extract/', extract_data, name='extract_data'),
    #path('check_value/', views.check_value, name='check_value'),

]
